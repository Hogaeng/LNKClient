package com.example.khk.lknmessenger;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by KHK on 2015-12-07.
 */
public class LobbyActivity extends Activity {

    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lobbywindow);
    }
}
